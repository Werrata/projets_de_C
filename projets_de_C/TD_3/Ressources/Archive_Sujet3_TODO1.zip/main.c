#include "fonctions.h"

int main(void) {
	types()
	return 0;
}
