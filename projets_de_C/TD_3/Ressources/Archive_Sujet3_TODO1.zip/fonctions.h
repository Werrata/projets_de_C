#include <stdio.h>
#include <limits.h>
#include <float.h>

void types();
void convImp();
void convExp();
